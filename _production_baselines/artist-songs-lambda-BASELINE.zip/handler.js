// BNDY Artist Songs Lambda - MVP: Add to Playbook
const AWS = require('aws-sdk');
const dynamodb = new AWS.DynamoDB.DocumentClient({ region: 'eu-west-2' });
const crypto = require('crypto');
const jwt = require('jsonwebtoken');

// Configuration
const JWT_SECRET = process.env.JWT_SECRET;

// Parse cookies from event
const parseCookies = (cookieHeader) => {
  if (!cookieHeader) return {};
  return cookieHeader.split(';').reduce((cookies, cookie) => {
    const [name, value] = cookie.trim().split('=');
    cookies[name] = value;
    return cookies;
  }, {});
};

// Extract userId from JWT session cookie
const extractUserId = (event) => {
  let sessionToken = null;

  // HTTP API v2 format - cookies array
  if (event.cookies && Array.isArray(event.cookies)) {
    const cookieString = event.cookies.find(c => c.startsWith('bndy_session='));
    if (cookieString) {
      sessionToken = cookieString.split('=')[1];
    }
  }

  // HTTP API v1 format OR fallback - Cookie header
  if (!sessionToken) {
    const cookieHeader = event.headers?.Cookie || event.headers?.cookie || '';
    const cookies = parseCookies(cookieHeader);
    sessionToken = cookies.bndy_session;
  }

  if (!sessionToken) {
    return null;
  }

  try {
    const session = jwt.verify(sessionToken, JWT_SECRET);
    return session.userId;
  } catch (error) {
    console.error('[AUTH] JWT verification failed:', error.message);
    return null;
  }
};

exports.handler = async (event, context) => {
  const method = event.requestContext?.http?.method || event.httpMethod;
  const path = event.requestContext?.http?.path || event.rawPath || event.path;

  console.log('[Artist Songs Lambda] Processing request:', { method, path });
  context.callbackWaitsForEmptyEventLoop = false;

  try {
    const artistId = event.pathParameters?.artistId;
    const artistSongId = event.pathParameters?.artistSongId;
    const userId = extractUserId(event);

    // POST /api/artists/{artistId}/playbook - Add song
    if (method === 'POST' && path.includes('/playbook') && artistId) {
      return await handleAddSongToPlaybook(JSON.parse(event.body), artistId);
    }

    // GET /api/artists/{artistId}/playbook - List playbook
    if (method === 'GET' && path.includes('/playbook') && artistId) {
      return await handleGetPlaybook(artistId, event.queryStringParameters);
    }

    // PUT /api/artists/{artistId}/playbook/{artistSongId} - Update enrichments
    if (method === 'PUT' && artistSongId && path.includes('/playbook')) {
      return await handleUpdateSong(artistSongId, JSON.parse(event.body));
    }

    // DELETE /api/artists/{artistId}/playbook/{artistSongId} - Remove song
    if (method === 'DELETE' && artistSongId) {
      return await handleDeleteSong(artistSongId);
    }

    // POST /api/artists/{artistId}/pipeline/suggestions - Add song to pipeline
    if (method === 'POST' && path.includes('/pipeline/suggestions') && artistId) {
      return await handleAddSuggestion(JSON.parse(event.body), artistId, userId);
    }

    // GET /api/artists/{artistId}/pipeline - Get pipeline songs by status
    if (method === 'GET' && path.includes('/pipeline') && artistId) {
      return await handleGetPipeline(artistId, event.queryStringParameters);
    }

    // POST /api/artists/{artistId}/pipeline/{artistSongId}/vote - Vote on song
    if (method === 'POST' && artistSongId && path.includes('/vote')) {
      return await handleVote(artistSongId, artistId, userId, JSON.parse(event.body));
    }

    // DELETE /api/artists/{artistId}/pipeline/{artistSongId} - Delete suggestion (only by suggester)
    if (method === 'DELETE' && artistSongId && path.includes('/pipeline')) {
      return await handleDeleteSuggestion(artistSongId, userId);
    }

    // POST /api/artists/{artistId}/pipeline/{artistSongId}/rag - Update RAG status
    if (method === 'POST' && artistSongId && path.includes('/rag')) {
      return await handleUpdateRagStatus(artistSongId, userId, JSON.parse(event.body));
    }

    // PUT /api/artists/{artistId}/pipeline/{artistSongId}/status - Change status
    if (method === 'PUT' && artistSongId && path.includes('/status')) {
      return await handleChangeStatus(artistSongId, JSON.parse(event.body));
    }

    // PUT /api/artists/{artistId}/pipeline/{artistSongId}/comment - Update comment
    if (method === 'PUT' && artistSongId && path.includes('/comment')) {
      return await handleUpdateComment(artistSongId, JSON.parse(event.body));
    }

    return {
      statusCode: 404,
      headers: getCorsHeaders(),
      body: JSON.stringify({ error: 'Route not found' })
    };
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      headers: getCorsHeaders(),
      body: JSON.stringify({ error: error.message })
    };
  }
};

async function handleAddSongToPlaybook(body, artistId) {
  const now = new Date().toISOString();
  const artistSong = {
    id: crypto.randomUUID(),
    artist_id: artistId,
    song_id: body.song_id,
    status: 'playbook',
    custom_key: body.custom_key || null,
    custom_tempo: body.custom_tempo || null,
    tuning: body.tuning || 'standard',
    notes: body.notes || '',
    youtube_url: body.youtube_url || '',
    reference_url: body.reference_url || '',
    votes: [],
    readiness: [],
    vetos: [],
    last_performed_at: '1970-01-01T00:00:00.000Z',
    performance_count: 0,
    added_by_membership_id: body.added_by_membership_id,
    created_at: now,
    updated_at: now,
    promoted_to_playbook_at: now,
    last_status_change_at: now
  };

  await dynamodb.put({
    TableName: 'bndy-artist-songs',
    Item: artistSong
  }).promise();

  const globalSong = await getGlobalSong(body.song_id);

  return {
    statusCode: 201,
    headers: getCorsHeaders(),
    body: JSON.stringify({ ...artistSong, globalSong })
  };
}

async function handleGetPlaybook(artistId, queryParams) {
  const result = await dynamodb.query({
    TableName: 'bndy-artist-songs',
    IndexName: 'artist_id-status-index',
    KeyConditionExpression: 'artist_id = :artistId AND #status = :status',
    ExpressionAttributeNames: { '#status': 'status' },
    ExpressionAttributeValues: {
      ':artistId': artistId,
      ':status': 'playbook'
    }
  }).promise();

  let songs = await Promise.all(
    result.Items.map(async (artistSong) => {
      const globalSong = await getGlobalSong(artistSong.song_id);

      // Skip if global song has been deleted (orphaned record)
      if (!globalSong) {
        return null;
      }

      // Override global song title with custom title if set
      if (artistSong.custom_title) {
        globalSong.title = artistSong.custom_title;
      }

      return { ...artistSong, globalSong };
    })
  );

  // Filter out null entries (orphaned records)
  songs = songs.filter(song => song !== null);

  // Apply filters
  if (queryParams?.search) {
    const search = queryParams.search.toLowerCase();
    songs = songs.filter(s => 
      s.globalSong?.title?.toLowerCase().includes(search) ||
      s.globalSong?.artist_name?.toLowerCase().includes(search)
    );
  }

  return {
    statusCode: 200,
    headers: getCorsHeaders(),
    body: JSON.stringify(songs)
  };
}

async function handleUpdateSong(artistSongId, body) {
  const updates = [];
  const values = { ':now': new Date().toISOString() };

  if (body.title !== undefined) {
    updates.push('custom_title = :custom_title');
    values[':custom_title'] = body.title;
  }
  if (body.custom_key !== undefined) {
    updates.push('custom_key = :custom_key');
    values[':custom_key'] = body.custom_key;
  }
  if (body.custom_tempo !== undefined) {
    updates.push('custom_tempo = :custom_tempo');
    values[':custom_tempo'] = body.custom_tempo;
  }
  if (body.tuning !== undefined) {
    updates.push('tuning = :tuning');
    values[':tuning'] = body.tuning;
  }
  if (body.custom_duration !== undefined) {
    updates.push('custom_duration = :custom_duration');
    values[':custom_duration'] = body.custom_duration;
  }
  if (body.notes !== undefined) {
    updates.push('notes = :notes');
    values[':notes'] = body.notes;
  }
  if (body.youtube_url !== undefined) {
    updates.push('youtube_url = :youtube_url');
    values[':youtube_url'] = body.youtube_url;
  }
  if (body.reference_url !== undefined) {
    updates.push('reference_url = :reference_url');
    values[':reference_url'] = body.reference_url;
  }
  if (body.additional_url !== undefined) {
    updates.push('additional_url = :additional_url');
    values[':additional_url'] = body.additional_url;
  }
  if (body.guitar_chords_url !== undefined) {
    updates.push('guitar_chords_url = :guitar_chords_url');
    values[':guitar_chords_url'] = body.guitar_chords_url;
  }

  updates.push('updated_at = :now');

  const result = await dynamodb.update({
    TableName: 'bndy-artist-songs',
    Key: { id: artistSongId },
    UpdateExpression: 'SET ' + updates.join(', '),
    ExpressionAttributeValues: values,
    ReturnValues: 'ALL_NEW'
  }).promise();

  return {
    statusCode: 200,
    headers: getCorsHeaders(),
    body: JSON.stringify(result.Attributes)
  };
}

async function handleDeleteSong(artistSongId) {
  await dynamodb.delete({
    TableName: 'bndy-artist-songs',
    Key: { id: artistSongId }
  }).promise();

  return {
    statusCode: 204,
    headers: getCorsHeaders(),
    body: ''
  };
}

async function getGlobalSong(songId) {
  try {
    const result = await dynamodb.get({
      TableName: 'bndy-songs',
      Key: { id: songId }
    }).promise();

    if (!result.Item) return null;

    // Map DB fields to frontend expected fields
    const song = result.Item;
    return {
      ...song,
      artist_name: song.artistName || song.artist_name,
      thumbnail_url: song.albumImageUrl || song.thumbnail_url,
      spotify_url: song.spotifyUrl || song.spotify_url,
      preview_url: song.previewUrl || song.preview_url
    };
  } catch (error) {
    console.error('Error fetching global song:', error);
    return null;
  }
}

async function handleAddSuggestion(body, artistId, userId) {
  console.log('[Artist Songs Lambda] Adding suggestion to pipeline');

  if (!userId) {
    return {
      statusCode: 401,
      headers: getCorsHeaders(),
      body: JSON.stringify({ error: 'Authentication required' })
    };
  }

  const now = new Date().toISOString();
  const artistSong = {
    id: crypto.randomUUID(),
    artist_id: artistId,
    song_id: body.song_id,
    status: 'voting',

    votes: {
      [userId]: {
        value: body.initial_vote,
        updated_at: now
      }
    },

    rag_status: {},

    custom_key: null,
    custom_tempo: null,
    tuning: 'standard',
    notes: '',
    youtube_url: '',
    reference_url: '',

    suggested_by_user_id: userId,
    suggested_comment: body.suggested_comment || '',
    vote_score_percentage: null,

    last_performed_at: '1970-01-01T00:00:00.000Z',
    performance_count: 0,
    promoted_to_playbook_at: null,

    added_by_membership_id: body.added_by_membership_id,
    created_at: now,
    updated_at: now,
    last_status_change_at: now
  };

  console.log('[ADD_SUGGESTION] Created artistSong with vote for userId:', userId.substring(0, 8) + '...');

  await dynamodb.put({
    TableName: 'bndy-artist-songs',
    Item: artistSong
  }).promise();

  const globalSong = await getGlobalSong(body.song_id);

  return {
    statusCode: 201,
    headers: getCorsHeaders(),
    body: JSON.stringify({ ...artistSong, globalSong })
  };
}

async function handleGetPipeline(artistId, queryParams) {
  const status = queryParams?.status || 'voting';

  const result = await dynamodb.query({
    TableName: 'bndy-artist-songs',
    IndexName: 'artist_id-status-index',
    KeyConditionExpression: 'artist_id = :artistId AND #status = :status',
    ExpressionAttributeNames: { '#status': 'status' },
    ExpressionAttributeValues: {
      ':artistId': artistId,
      ':status': status
    }
  }).promise();

  let songs = await Promise.all(
    result.Items.map(async (artistSong) => {
      const globalSong = await getGlobalSong(artistSong.song_id);

      if (!globalSong) {
        console.log(`Warning: Orphaned artist-song record ${artistSong.id}`);
        return null;
      }

      return { ...artistSong, globalSong };
    })
  );

  songs = songs.filter(song => song !== null);

  return {
    statusCode: 200,
    headers: getCorsHeaders(),
    body: JSON.stringify(songs)
  };
}

async function handleVote(artistSongId, artistId, userId, body) {
  try {
    const now = new Date().toISOString();

    console.log('[VOTE] Starting vote handler', {
      artistSongId: artistSongId?.substring(0, 8) + '...',
      artistId: artistId?.substring(0, 8) + '...',
      userId: userId?.substring(0, 8) + '...',
      voteValue: body.vote_value
    });

    if (!userId) {
      console.error('[VOTE] No userId provided - authentication failed');
      return {
        statusCode: 401,
        headers: getCorsHeaders(),
        body: JSON.stringify({ error: 'Authentication required' })
      };
    }

    if (body.vote_value === undefined || body.vote_value === null || body.vote_value < 0 || body.vote_value > 5) {
      console.error('[VOTE] Invalid vote value:', body.vote_value);
      return {
        statusCode: 400,
        headers: getCorsHeaders(),
        body: JSON.stringify({ error: 'Invalid vote value. Must be between 0 and 5.' })
      };
    }

    const songResult = await dynamodb.get({
      TableName: 'bndy-artist-songs',
      Key: { id: artistSongId }
    }).promise();

    if (!songResult.Item) {
      return {
        statusCode: 404,
        headers: getCorsHeaders(),
        body: JSON.stringify({ error: 'Song not found' })
      };
    }

    const song = songResult.Item;
    const votes = song.votes || {};

    console.log('[VOTE] Current votes before update:', Object.keys(votes));

    votes[userId] = {
      value: body.vote_value,
      updated_at: now
    };

    console.log('[VOTE] Votes after adding new vote:', Object.keys(votes));

    const memberCountResult = await dynamodb.query({
      TableName: 'bndy-artist-memberships',
      IndexName: 'artist_id-index',
      KeyConditionExpression: 'artist_id = :artistId',
      ExpressionAttributeValues: { ':artistId': artistId }
    }).promise();

    const memberCount = memberCountResult.Items.length;
    const voteCount = Object.keys(votes).length;

    console.log('[VOTE] Member count:', memberCount, 'Vote count:', voteCount);

    const totalVotes = Object.values(votes).reduce((sum, v) => sum + v.value, 0);
    const scorePercentage = Math.round((totalVotes / (memberCount * 5)) * 100);

    const newStatus = (voteCount >= memberCount && song.status === 'voting') ? 'review' : song.status;
    const statusChanged = newStatus !== song.status;

    console.log('[VOTE] Status transition:', {
      oldStatus: song.status,
      newStatus,
      willPromote: statusChanged,
      scorePercentage
    });

    await dynamodb.update({
      TableName: 'bndy-artist-songs',
      Key: { id: artistSongId },
      UpdateExpression: 'SET votes = :votes, vote_score_percentage = :score, #status = :status, updated_at = :now' +
        (statusChanged ? ', last_status_change_at = :now' : ''),
      ExpressionAttributeNames: { '#status': 'status' },
      ExpressionAttributeValues: {
        ':votes': votes,
        ':score': scorePercentage,
        ':status': newStatus,
        ':now': now
      }
    }).promise();

    const globalSong = await getGlobalSong(song.song_id);

    console.log('[VOTE] Vote recorded successfully', {
      songTitle: globalSong?.title,
      finalVoteCount: voteCount,
      finalMemberCount: memberCount,
      finalStatus: newStatus
    });

    return {
      statusCode: 200,
      headers: getCorsHeaders(),
      body: JSON.stringify({
        ...song,
        votes,
        vote_score_percentage: scorePercentage,
        status: newStatus,
        updated_at: now,
        globalSong
      })
    };
  } catch (error) {
    console.error('[VOTE] Error in handleVote:', error);
    return {
      statusCode: 500,
      headers: getCorsHeaders(),
      body: JSON.stringify({
        error: 'Failed to submit vote',
        message: error.message,
        details: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
}

async function handleUpdateRagStatus(artistSongId, userId, body) {
  const now = new Date().toISOString();

  const songResult = await dynamodb.get({
    TableName: 'bndy-artist-songs',
    Key: { id: artistSongId }
  }).promise();

  if (!songResult.Item) {
    return {
      statusCode: 404,
      headers: getCorsHeaders(),
      body: JSON.stringify({ error: 'Song not found' })
    };
  }

  const song = songResult.Item;
  const ragStatus = song.rag_status || {};

  ragStatus[userId] = {
    status: body.status,
    updated_at: now
  };

  await dynamodb.update({
    TableName: 'bndy-artist-songs',
    Key: { id: artistSongId },
    UpdateExpression: 'SET rag_status = :rag_status, updated_at = :now',
    ExpressionAttributeValues: {
      ':rag_status': ragStatus,
      ':now': now
    }
  }).promise();

  const globalSong = await getGlobalSong(song.song_id);

  return {
    statusCode: 200,
    headers: getCorsHeaders(),
    body: JSON.stringify({
      ...song,
      rag_status: ragStatus,
      updated_at: now,
      globalSong
    })
  };
}

async function handleChangeStatus(artistSongId, body) {
  const now = new Date().toISOString();
  const newStatus = body.status;

  const updates = ['#status = :status', 'updated_at = :now', 'last_status_change_at = :now'];
  const values = {
    ':status': newStatus,
    ':now': now
  };

  if (newStatus === 'playbook') {
    updates.push('promoted_to_playbook_at = :now');
  }

  const result = await dynamodb.update({
    TableName: 'bndy-artist-songs',
    Key: { id: artistSongId },
    UpdateExpression: 'SET ' + updates.join(', '),
    ExpressionAttributeNames: { '#status': 'status' },
    ExpressionAttributeValues: values,
    ReturnValues: 'ALL_NEW'
  }).promise();

  const globalSong = await getGlobalSong(result.Attributes.song_id);

  return {
    statusCode: 200,
    headers: getCorsHeaders(),
    body: JSON.stringify({ ...result.Attributes, globalSong })
  };
}

async function handleUpdateComment(artistSongId, body) {
  const now = new Date().toISOString();

  const result = await dynamodb.update({
    TableName: 'bndy-artist-songs',
    Key: { id: artistSongId },
    UpdateExpression: 'SET suggested_comment = :comment, updated_at = :now',
    ExpressionAttributeValues: {
      ':comment': body.comment,
      ':now': now
    },
    ReturnValues: 'ALL_NEW'
  }).promise();

  const globalSong = await getGlobalSong(result.Attributes.song_id);

  return {
    statusCode: 200,
    headers: getCorsHeaders(),
    body: JSON.stringify({ ...result.Attributes, globalSong })
  };
}

async function handleDeleteSuggestion(artistSongId, userId) {
  console.log('[DELETE_SUGGESTION] Starting', {
    artistSongId: artistSongId?.substring(0, 8) + '...',
    userId: userId ? userId.substring(0, 8) + '...' : 'NULL'
  });

  if (!userId) {
    console.error('[DELETE_SUGGESTION] ERROR: No userId provided - authentication required');
    return {
      statusCode: 401,
      headers: getCorsHeaders(),
      body: JSON.stringify({ error: 'Authentication required' })
    };
  }

  const songResult = await dynamodb.get({
    TableName: 'bndy-artist-songs',
    Key: { id: artistSongId }
  }).promise();

  if (!songResult.Item) {
    return {
      statusCode: 404,
      headers: getCorsHeaders(),
      body: JSON.stringify({ error: 'Song not found' })
    };
  }

  const song = songResult.Item;

  if (song.suggested_by_user_id !== userId) {
    console.error('[DELETE_SUGGESTION] ERROR: User is not the suggester', {
      requestingUserId: userId.substring(0, 8) + '...',
      suggestedByUserId: song.suggested_by_user_id?.substring(0, 8) + '...'
    });
    return {
      statusCode: 403,
      headers: getCorsHeaders(),
      body: JSON.stringify({ error: 'Only the suggester can delete this song' })
    };
  }

  await dynamodb.delete({
    TableName: 'bndy-artist-songs',
    Key: { id: artistSongId }
  }).promise();

  console.log('[DELETE_SUGGESTION] SUCCESS: Song deleted by suggester');

  return {
    statusCode: 204,
    headers: getCorsHeaders(),
    body: ''
  };
}

function getCorsHeaders() {
  return {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization,Cookie',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
    'Access-Control-Allow-Credentials': 'true'
  };
}
